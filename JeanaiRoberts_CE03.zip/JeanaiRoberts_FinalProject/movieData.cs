﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeanaiRoberts_FinalProject
{
    class movieData
    {
        string movieTitle;
        string relased;
        string rated;
        string runtime;
        string genre;
        string plot;

        
    }
}
